//
//  AppDelegate.swift
//  Demo3DTouch
//
//  Created by Apple on 21/11/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var launchedShortcutItem: UIApplicationShortcutItem?
 
    
    enum ShortcutIdentifier: String {
        case Share
        case Search
        
        init?(fullNameForType: String) {
            guard let last =  fullNameForType.components(separatedBy: ".").last  else {return nil}
            self.init(rawValue: last)
        }
        var type: String {
            return Bundle.main.bundleIdentifier! + ".\(self.rawValue)"
        }
        
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        if let shortcutItem = launchOptions?[UIApplication.LaunchOptionsKey.shortcutItem] as? UIApplicationShortcutItem {
            launchedShortcutItem = shortcutItem
        }
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
        guard let shortcutItem = launchedShortcutItem else {return}
        _ = handleShortcutItem(item: shortcutItem)
        launchedShortcutItem = nil
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        completionHandler(handleShortcutItem(item: shortcutItem))
    }
   
    
    func handleShortcutItem(item: UIApplicationShortcutItem) -> Bool{
        var handle = false
        guard ShortcutIdentifier(fullNameForType: item.type) != nil else {return false}
        guard let shortcutType = item.type as String? else {return false }
        
        let mainStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        
        var reqViewController: UIViewController!
        
        switch shortcutType {
        case ShortcutIdentifier.Share.type:
            reqViewController = mainStoryboard.instantiateViewController(withIdentifier: "ShareViewController") as! ShareViewController
            handle = true
            
        case ShortcutIdentifier.Search.type:
            reqViewController = mainStoryboard.instantiateViewController(withIdentifier: "SearchViewController") as! SearchViewController
            handle = true

        default:
            print("Shortcut Item handle Func")
        }
        
        if let homeVc = self.window?.rootViewController as? UINavigationController {
            homeVc.pushViewController(reqViewController, animated: true)
        }else{
            return false
        }
        return handle
    }
    
}

